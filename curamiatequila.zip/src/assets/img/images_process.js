import process1 from "./img/process1.jpg"
import slider1 from "./img/slider1.jpg"
import slider2 from "./img/slider2.jpg"
import slider3 from "./img/slider3.jpg"
import slider4 from "./img/slider4.jpg"
import slider5 from "./img/slider5.jpg"
import slider6 from "./img/slider6.jpg"


const imgs = {
    "img1" : process1,
    "slider1" : slider1,
    "slider2" : slider2,
    "slider3" : slider3,
    "slider4" : slider4,
    "slider5" : slider5,
    "slider6" : slider6,

}

export default imgs