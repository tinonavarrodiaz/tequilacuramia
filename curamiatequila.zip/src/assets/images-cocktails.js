import img1 from "./img/cocktails/01.jpg"
import img2 from "./img/cocktails/02.jpg"
import img3 from "./img/cocktails/03.jpg"
import img4 from "./img/cocktails/04.jpg"
import img5 from "./img/cocktails/05a.jpg"
import img6 from "./img/cocktails/06.jpg"
import img7 from "./img/cocktails/07.jpg"
import img8 from "./img/cocktails/08.jpg"
import img9 from "./img/cocktails/09.jpg"

const ImagesCocktails = {
  img1, img2, img3, img4, img5, img6, img7, img8, img9
}

export default ImagesCocktails