import about1 from "./img/about1.jpg"
import about2 from "./img/about2.jpg"
import aboutBottle from "./img/about-bottle.png"

const imgs = {
    "img1" : about1,
    "img2" : about2,
    "bottle" : aboutBottle,
}
export default imgs
