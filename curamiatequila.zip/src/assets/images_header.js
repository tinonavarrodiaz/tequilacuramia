import menu from "./img/menu.png"
import menuLight from "./img/menu2.png"
import logo from "../assets/img/logo.png";


const imgs = {
    "menu" : menu,
    "menuLight" : menuLight,
    "logo" : logo
}

export default imgs